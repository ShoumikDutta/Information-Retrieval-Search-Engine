package searchEngine.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import searchEngine.SearchController;
import searchEngine.SearchResult;
import searchEngine.WebSearchResult;

@Path("/api/search")
public class SearchResource {

    private SearchController searchController = new SearchController();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response search(@QueryParam("q") String queryText) {
        List<SearchResult> results = searchController.search(queryText);
        
        // demo
        List<SearchResult> demoResults = new ArrayList<>();
        SearchResult r = new WebSearchResult();

        r.setResultId("R-1");
        r.setTitle("Test result for: " + queryText);
        r.setSnippet("This is a demo search result.");
        r.setRankScore(1.0);

        demoResults.add(r);
        System.out.println(demoResults.get(0));
        return Response.ok(demoResults).build();
    }
}
